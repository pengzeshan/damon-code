  here are the steps to be run:
  1. In pseudo_quantropi, run 
  cd pseudo_quantropi
  make all
  sudo make load
  sudo make install
  
  2. Check the status, run 
  /usr/bin/pseudo_quantropi status

  It should show that both /dev/randomm and /dev/urandom are linked with pseudo_quantropi:
  ls -i /dev/random
  ls -i /dev/urandom
  ls -i /dev/pseudo_quantropi 
  
  3. build the tests:
  cd ../tests/
  make all

  4. run the tests:
  ./.output/test-random.out 
  ./.output/test-urandom.out 
  ./.output/test-pseudo_quantropi.out 

  The result of the above three runs are from /dev/pseudo_quantropi 
  (please note that the first 5 bytes of all random numbers from /dev/pseudo_quantropi are 01 01 01 01 01 )

  5. We can always check the status:  
  sudo /usr/bin/pseudo_quantropi status

  6. Stop and recover the original random and urandom:
  sudo /usr/bin/pseudo_quantropi default
  cd pseudo_quantropi
  sudo make uninstall
  sudo make unload

  ls -i /dev/random
  ls -i /dev/urandom
  
  ./.output/test-random.out 
  ./.output/test-urandom.out 

  In the case, anything happens unexpected, run the following commands:
  sudo rm -rf /dev/random
  sudo mknod -m 444 /dev/random c 1 8 
  sudo rm -rf /dev/urandom
  sudo mknod -m 444 /dev/urandom c 1 9

  Test it:
  ./.output/test-urandom.out 
  ./.output/test-random.out 
  ls -i /dev/random
  ls -i /dev/urandom
