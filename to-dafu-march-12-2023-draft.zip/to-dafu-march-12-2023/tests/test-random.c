	
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

// static char * dev_random_filename = "/dev/pseudo_random";
static char * dev_random_filename = "/dev/random";
static void print_data(char * buf, int len) {
    unsigned char * tmp = (unsigned char*) buf;
    for(int i = 0; i < len; i++) {
        printf("%02x ", *(tmp+i));
        fflush(stdout);
    }
    printf("\n");
}

void test_random(void) {
    printf("open %s\n", dev_random_filename);
    int fd_random_data = open(dev_random_filename, O_RDONLY);
    if (fd_random_data < 0)
    {
        printf(" error in opening %s\n", dev_random_filename);
    }
    else
    {
        char my_random_data[50];
        size_t random_dataLen = 0;
        while (random_dataLen < sizeof my_random_data)
        {  
            printf("read %ld bytes from %s:\n", sizeof my_random_data, dev_random_filename);
            size_t result = read(fd_random_data, my_random_data + random_dataLen, (sizeof my_random_data) - random_dataLen);
            if (result < 0)
            {
                printf(" error in reading %s with ret=%ld\n", dev_random_filename, result);
            }
            random_dataLen += result;
        }
        close(fd_random_data);
        print_data(my_random_data, sizeof(my_random_data));
        printf("\n\n\n");
    }
}


int main(void) {
    test_random();
    return 0;
}