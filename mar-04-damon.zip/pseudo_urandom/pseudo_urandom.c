#define MY_NAME "pseudo_urandom"
#define my_MODULE_NAME MY_NAME
#define my_DEVICE_NAME MY_NAME
#define my_CLASS_NAME  MY_NAME

#include <linux/device.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/uaccess.h>

MODULE_AUTHOR("CIA-penguins");
MODULE_LICENSE("GPL v2");
MODULE_DESCRIPTION("my test");
MODULE_VERSION("0.0.1");

static char *my_name = "CIA-penguins";
// S_IRUGO: everyone can read
// S_IWUSR: user can also write
module_param(my_name, charp, S_IRUGO);
MODULE_PARM_DESC(my_name, "Check /var/log/kern.log");

static int    my_major_number;
static char   my_message[256] = {0};
static short  my_message_size;
static int    my_num_opens = 0;
static struct class*  my_test_class  = NULL;
static struct device* my_test_device = NULL;
static DEFINE_MUTEX(my_io_mutex);

static int     my_dev_open(struct inode *, struct file *);
static int     dev_release(struct inode *, struct file *);
static ssize_t my_dev_read(struct file *, char *, size_t, loff_t *);
static ssize_t my_dev_write(struct file *, const char *, size_t, loff_t *);

static char my_internal_pseudo_random(char input);

static struct file_operations my_fops =
{
   .open = my_dev_open,
   .read = my_dev_read,
   .write = my_dev_write,
   .release = dev_release,
};

static void my_init_module_id(char * test_message) {
    const char * tmp = my_MODULE_NAME;
    int i = 0;
    for(; i<strlen(my_MODULE_NAME); i++)
        test_message[i] = tmp[i];
    test_message[i] = ':';
}

static int __init my_mod_init(void)
{
    pr_info("OK: %s loaded 0x%p\n", my_MODULE_NAME, my_mod_init);

    mutex_init(&my_io_mutex);

    my_major_number = register_chrdev(0, my_DEVICE_NAME, &my_fops);
    if (my_major_number < 0) {
        pr_alert("ERR: %s register\n", my_MODULE_NAME);
        return my_major_number;
    }
    pr_info("OK: %s(%d) registered\n", my_MODULE_NAME, my_major_number);

    my_test_class = class_create(THIS_MODULE, my_CLASS_NAME);
    if (IS_ERR(my_test_class)) {
        unregister_chrdev(my_major_number, my_DEVICE_NAME);
        pr_alert("%s: failed to register device class\n", my_MODULE_NAME);
        return PTR_ERR(my_test_class);
    }
    pr_info("OK: %s device registered\n", my_MODULE_NAME);

    my_test_device = device_create(my_test_class, NULL, MKDEV(my_major_number, 0), NULL, my_DEVICE_NAME);
    if (IS_ERR(my_test_device)) {
        class_destroy(my_test_class);
        unregister_chrdev(my_major_number, my_DEVICE_NAME);
        pr_alert("%s: failed to create the device\n", my_DEVICE_NAME);
        return PTR_ERR(my_test_device);
    }
    pr_info("OK: %s device created\n", my_DEVICE_NAME);

    return 0;
}

static void __exit my_mod_exit(void)
{
    pr_info("OK: %s unloading...\n", my_MODULE_NAME);
    device_destroy(my_test_class, MKDEV(my_major_number, 0));
    class_unregister(my_test_class);
    class_destroy(my_test_class);
    unregister_chrdev(my_major_number, my_DEVICE_NAME);
    mutex_destroy(&my_io_mutex);
    pr_info("OK: %s device unregistered\n", my_MODULE_NAME);
}

static int my_dev_open(struct inode *inodep, struct file *filep){
    if(!mutex_trylock(&my_io_mutex)) {
        pr_alert("ERR: %s: device in use", my_MODULE_NAME);
        return -EBUSY;
    }

    my_num_opens++;
    pr_info("OK: %s device opened %d time(s)\n", my_MODULE_NAME, my_num_opens);
    return 0;
}

static ssize_t my_dev_read(struct file *filep, char *buffer, size_t len, loff_t *offset){
   int error_count = 0;
   int i = 0;
   char test_message[256] = { 0 };

   my_init_module_id(test_message);
   for (; i<my_message_size; i++) {
       test_message[i+strlen(my_MODULE_NAME)+1] = my_internal_pseudo_random(my_message[i]);
   }

   error_count = copy_to_user(buffer, test_message, my_message_size+strlen(my_MODULE_NAME)+1);

   if (error_count==0) {
      pr_info("OK: %s sent %ld characters\n", my_MODULE_NAME, my_message_size+strlen(my_MODULE_NAME)+1);
      my_message_size = 0;
      return 0;
   }
   else {
      pr_err("ERR: %s send %d characters\n", my_MODULE_NAME, error_count);
      return -EFAULT;              
   }
}

static ssize_t my_dev_write(struct file *filep, const char *buffer, size_t len, loff_t *offset){
    int num = copy_from_user(my_message, buffer, len);
    my_message_size = len;
    pr_info("OK: %s received %zu characters\n", my_MODULE_NAME, len);
    return len;
}

static int dev_release(struct inode *inodep, struct file *filep){
     mutex_unlock(&my_io_mutex);
     pr_info("OK: %s: device closed\n", my_MODULE_NAME);
     return 0;
}

static char my_internal_pseudo_random(char input) {
    if ((input >= 'a' && input <= 'm') || (input >= 'A' && input <= 'M')) {
       return input + 10;
    }
    if ((input >= 'n' && input <= 'z') || (input >= 'N' && input <= 'Z')) {
        return input - 10;
    }
    return input;
}
    

module_init(my_mod_init);
module_exit(my_mod_exit);
