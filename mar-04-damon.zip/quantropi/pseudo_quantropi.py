# write a function:
#   It takes a random number as the input parameter
#   It output the value of + - * /

#   For example, the input of the function is a
#   the output of the function will be (a + a) + (a * a)  + (a - a) + (a/a) if a != 0
#   the output of the function will be (a + a) + (a * a)  + (a - a) + (1)   if a == 0
print("What number will you give me?")
number_value = float(input())
if number_value == str:
    print("Sorry we need a number")
    exit()
elif number_value == int or float:
    if number_value != 0:
        print(number_value * number_value + number_value + number_value + 1)
    elif number_value == 0:
        print(1)

