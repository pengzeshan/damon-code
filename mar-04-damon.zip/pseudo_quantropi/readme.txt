1. check if the following cmd available:
restorecon, chcon
if not, install with the following cmd line:
sudo apt-get install policycoreutils

2. 