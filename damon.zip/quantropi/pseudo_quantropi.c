// https://github.com/Embetronicx/Tutorials/tree/master/Linux/Device_Driver/Misc_Driver

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/slab.h> /* For kmalloc */
#include <linux/gfp.h>
#include <linux/vmalloc.h>    /* For vmalloc */
#include <linux/uaccess.h>    /* For copy_to_user */
#include <linux/miscdevice.h> /* For misc_register (the /dev/pseudo_quantropi) device */
#include <linux/time.h>       /* For getnstimeofday/ktime_get_real_ts64 */
#include <linux/proc_fs.h>    /* For /proc filesystem */
#include <linux/seq_file.h>   /* For seq_print */
#include <linux/mutex.h>
#include <linux/delay.h>
#include <linux/kthread.h>

#define MY_MODULE_AUTHOR "CIA-penguins"
#define MY_DRIVER_DESC "A pseudio-random number generator."
#define MY_TEST_DEVICE_NAME "pseudo_quantropi"
#define MY_APP_VERSION "0.0.1"

// Amount of time in seconds, the background thread should sleep between each operation. Recommended prime
#define MY_THREAD_SLEEP_VALUE 11

// Size of Array.  Must be >= 65. (actual size used will be 65, anything greater is thrown away). Recommended prime
#define MY_RND_ARRAY_SIZE 67
// Number of 512b Array (Must be power of 2)
#define MY_NUM_OF_RND_ARRAYS 16

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 12, 0)
#define MY_COPY_TO_USER raw_copy_to_user
#define MY_COPY_FROM_USER raw_copy_from_user
#else
#define MY_COPY_TO_USER copy_to_user
#define MY_COPY_FROM_USER copy_from_user
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0)
#define MY_KERNEL_TIME_GET_NS ktime_get_real_ts64
#define MY_TIMESPEC timespec64
#else
#define MY_KERNEL_TIME_GET_NS getnstimeofday
#define MY_TIMESPEC timespec
#endif

static int my_device_open(struct inode *, struct file *);
static int my_device_release(struct inode *, struct file *);
static ssize_t my_device_read(struct file *, char *, size_t, loff_t *);
static ssize_t my_device_write(struct file *, const char *, size_t, loff_t *);
static uint64_t my_xorshft64(void);
static uint64_t my_xorshft128(void);
static int my_nextbuffer(void);
static void my_update_array(int);

static void my_seed_PRND_r128_0(void);
static void my_seed_PRND_r128_1(void);
static void my_seed_PRND_r64(void);
static int my_proc_read(struct seq_file *m, void *v);
static int my_proc_open(struct inode *inode, struct file *file);

static int my_background_work_thread(void *data);

/*
 * Global variables are declared as static, so are global within the file.
 */
// https://embetronicx.com/tutorials/linux/device-drivers/misc-device-driver/
static struct file_operations my_file_ops = {
    .owner = THIS_MODULE,

    .open = my_device_open,
    .release = my_device_release,

    .read = my_device_read,
    .write = my_device_write,
};

static struct miscdevice pseudo_quantropi_dev = {
    MISC_DYNAMIC_MINOR,
    "pseudo_quantropi",
    &my_file_ops};

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0)
static struct proc_ops my_proc_file_ops = {

    .proc_open = my_proc_open,
    .proc_release = single_release,

    .proc_read = seq_read,
    .proc_lseek = seq_lseek};
#else
static const struct file_operations my_proc_file_ops = {
    .owner = THIS_MODULE,

    .read = seq_read,
    .open = my_proc_open,

    .llseek = seq_lseek,
    .release = single_release,
};
#endif

static struct mutex g_mutex_update_array;
static struct mutex g_mutex_open;
static struct mutex g_mutex_array_busy;
static struct mutex g_mutex_update_pos;

static struct task_struct *g_kernel_thread;

uint64_t g_rnd_xorshft64;                            /* Used for my_xorshft64 */
uint64_t g_rnd_xorshft128[2];                        /* Used for my_xorshft128 */
uint64_t (*g_my_prng_arrays)[MY_NUM_OF_RND_ARRAYS + 5]; /* Array of Array of SECURE RND numbers */
uint16_t g_arrays_busy_flags = 0;                    /* Binary Flags for Busy Arrays */
int g_array_pos = 0;                                 /* Array reserved to determine which buffer to use */
struct MY_TIMESPEC g_ts;

int16_t g_dev_open_current; /* pseudo_quantropi device current open count */
int32_t g_dev_open_total;   /* pseudo_quantropi device total open count */
uint64_t g_generated_count; /* Total generated (512byte) */

int my_module_init(void)
{
    int16_t tmpIndex, tmpPos;

    g_dev_open_current = 0;
    g_dev_open_total = 0;
    g_generated_count = 0;

    mutex_init(&g_mutex_update_array);
    mutex_init(&g_mutex_open);
    mutex_init(&g_mutex_array_busy);
    mutex_init(&g_mutex_update_pos);

    /*
     * Entropy Initialize #1
     */
    MY_KERNEL_TIME_GET_NS(&g_ts);
    g_rnd_xorshft64 = (uint64_t)g_ts.tv_nsec;
    g_rnd_xorshft128[0] = my_xorshft64();
    g_rnd_xorshft128[1] = my_xorshft64();

    /*
     * Register char device
     */
    if (misc_register(&pseudo_quantropi_dev))
        printk(KERN_INFO "[pseudo_quantropi] my_module_init /dev/pseudo_quantropi driver registion failed..\n");
    else
        printk(KERN_INFO "[pseudo_quantropi] my_module_init /dev/pseudo_quantropi driver registered..\n");

    /*
     * Create /proc/pseudo_quantropi
     */
    if (!proc_create("pseudo_quantropi", 0, NULL, &my_proc_file_ops))
        printk(KERN_INFO "[pseudo_quantropi] my_module_init /proc/pseudo_quantropi registion failed..\n");
    else
        printk(KERN_INFO "[pseudo_quantropi] my_module_init /proc/pseudo_quantropi registion regisered..\n");

    printk(KERN_INFO "[pseudo_quantropi] my_module_init Module version         : " MY_APP_VERSION "\n");

    printk(KERN_INFO "-----------------------:----------------------\n");
    printk(KERN_INFO "Author                 : CIA-penguins\n");

    g_my_prng_arrays = kmalloc((MY_NUM_OF_RND_ARRAYS + 1) * MY_RND_ARRAY_SIZE * sizeof(uint64_t), GFP_KERNEL);
    while (!g_my_prng_arrays)
    {
        printk(KERN_INFO "[pseudo_quantropi] my_module_init kmalloc failed to allocate initial memory.  retrying...\n");
        g_my_prng_arrays = kmalloc((MY_NUM_OF_RND_ARRAYS + 1) * MY_RND_ARRAY_SIZE * sizeof(uint64_t), GFP_KERNEL);
    }

    my_seed_PRND_r128_0();
    my_seed_PRND_r128_1();
    my_seed_PRND_r64();

    for (tmpPos = 0; tmpPos <= MY_NUM_OF_RND_ARRAYS; tmpPos++)
    {
        for (tmpIndex = 0; tmpIndex <= MY_RND_ARRAY_SIZE; tmpIndex++)
        {
            g_my_prng_arrays[tmpPos][tmpIndex] = my_xorshft128();
        }
        my_update_array(tmpPos);
    }

    g_kernel_thread = kthread_create(my_background_work_thread, NULL, "pseudo_quantropi-g_kernel_thread");
    wake_up_process(g_kernel_thread);

    return 0;
}

void my_module_exit(void)
{
    kthread_stop(g_kernel_thread);

    misc_deregister(&pseudo_quantropi_dev);

    remove_proc_entry("pseudo_quantropi", NULL);

    printk(KERN_INFO "[pseudo_quantropi] my_module_exit pseudo_quantropi deregisered..\n");
}

static int my_device_open(struct inode *inode, struct file *file)
{
    while (mutex_lock_interruptible(&g_mutex_open));

    g_dev_open_current++;
    g_dev_open_total++;
    mutex_unlock(&g_mutex_open);

    return 0;
}

static int my_device_release(struct inode *inode, struct file *file)
{
    while (mutex_lock_interruptible(&g_mutex_open));

    g_dev_open_current--;
    mutex_unlock(&g_mutex_open);

    return 0;
}

static ssize_t my_device_read(struct file *file, char *buf, size_t requestedCount, loff_t *ppos)
{
    int tmpPos;
    int Block, ret;
    char *new_buf; /* Buffer to hold numbers to send */
    bool isVMalloc = 0;

    new_buf = kmalloc((requestedCount + 512) * sizeof(uint8_t), GFP_KERNEL | __GFP_NOWARN);
    while (!new_buf)
    {
        isVMalloc = 1;
        new_buf = vmalloc((requestedCount + 512) * sizeof(uint8_t));
    }

    /*
     * Select a RND array
     */
    while (mutex_lock_interruptible(&g_mutex_array_busy))
        ;

    tmpPos = my_nextbuffer();

    while ((g_arrays_busy_flags & 1 << tmpPos) == (1 << tmpPos))
    {
        tmpPos += 1;
        if (tmpPos >= MY_NUM_OF_RND_ARRAYS)
        {
            tmpPos = 0;
        }
    }

    /*
     * Mark the Arry as busy by setting the flag
     */
    g_arrays_busy_flags += (1 << tmpPos);
    mutex_unlock(&g_mutex_array_busy);

    for (Block = 0; Block <= (requestedCount / 512); Block++)
    {
        memcpy(new_buf + (Block * 512), g_my_prng_arrays[tmpPos], 512);
        my_update_array(tmpPos);
    }

    /*
     * Send new_buf to device
     */
    ret = MY_COPY_TO_USER(buf, new_buf, requestedCount);

    if (isVMalloc)
    {
        vfree(new_buf);
    }
    else
    {
        kfree(new_buf);
    }

    if (mutex_lock_interruptible(&g_mutex_array_busy))
        return -ERESTARTSYS;
    g_arrays_busy_flags -= (1 << tmpPos);
    mutex_unlock(&g_mutex_array_busy);

    return requestedCount;
}

static ssize_t my_device_write(struct file *file, const char __user *buf, size_t receivedCount, loff_t *ppos)
{
    char *newdata;
    int result;

    newdata = kmalloc(receivedCount, GFP_KERNEL);
    while (!newdata)
    {
        newdata = kmalloc(receivedCount, GFP_KERNEL);
    }
    result = MY_COPY_FROM_USER(newdata, buf, receivedCount);
    kfree(newdata);

    return receivedCount;
}

static void my_update_array(int tmpPos)
{
    int16_t tmpIndex;
    int64_t X, Y, Z1, Z2, Z3;

    while (mutex_lock_interruptible(&g_mutex_update_array));

    g_generated_count++;

    Z1 = my_xorshft64();
    Z2 = my_xorshft64();
    Z3 = my_xorshft64();
    if ((Z1 & 1) == 0)
    {

        for (tmpIndex = 0; tmpIndex < (MY_RND_ARRAY_SIZE - 4); tmpIndex = tmpIndex + 4)
        {
            X = my_xorshft128();
            Y = my_xorshft128();
            g_my_prng_arrays[tmpPos][tmpIndex] = g_my_prng_arrays[tmpPos][tmpIndex + 1] ^ X ^ Y;
            g_my_prng_arrays[tmpPos][tmpIndex + 1] = g_my_prng_arrays[tmpPos][tmpIndex + 2] ^ Y ^ Z1;
            g_my_prng_arrays[tmpPos][tmpIndex + 2] = g_my_prng_arrays[tmpPos][tmpIndex + 3] ^ X ^ Z2;
            g_my_prng_arrays[tmpPos][tmpIndex + 3] = X ^ Y ^ Z3;
        }
    }
    else
    {
        for (tmpIndex = 0; tmpIndex < (MY_RND_ARRAY_SIZE - 4); tmpIndex = tmpIndex + 4)
        {
            X = my_xorshft128();
            Y = my_xorshft128();
            g_my_prng_arrays[tmpPos][tmpIndex] = g_my_prng_arrays[tmpPos][tmpIndex + 1] ^ X ^ Z2;
            g_my_prng_arrays[tmpPos][tmpIndex + 1] = g_my_prng_arrays[tmpPos][tmpIndex + 2] ^ X ^ Y;
            g_my_prng_arrays[tmpPos][tmpIndex + 2] = g_my_prng_arrays[tmpPos][tmpIndex + 3] ^ Y ^ Z3;
            g_my_prng_arrays[tmpPos][tmpIndex + 3] = X ^ Y ^ Z1;
        }
    }

    mutex_unlock(&g_mutex_update_array);
}

static void my_seed_PRND_r128_0(void)
{
    MY_KERNEL_TIME_GET_NS(&g_ts);
    g_rnd_xorshft128[0] = (g_rnd_xorshft128[0] << 31) ^ (uint64_t)g_ts.tv_nsec;
}

static void my_seed_PRND_r128_1(void)
{
    MY_KERNEL_TIME_GET_NS(&g_ts);
    g_rnd_xorshft128[1] = (g_rnd_xorshft128[1] << 24) ^ (uint64_t)g_ts.tv_nsec;
}

static void my_seed_PRND_r64(void)
{
    MY_KERNEL_TIME_GET_NS(&g_ts);
    g_rnd_xorshft64 = (g_rnd_xorshft64 << 32) ^ (uint64_t)g_ts.tv_nsec;
}

static uint64_t my_xorshft64(void)
{
    uint64_t z = (g_rnd_xorshft64 += 0x9E3779B97F4A7C15ULL);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

static uint64_t my_xorshft128(void)
{
    uint64_t s1 = g_rnd_xorshft128[0];
    const uint64_t s0 = g_rnd_xorshft128[1];
    g_rnd_xorshft128[0] = s0;
    s1 ^= s1 << 23;
    return (g_rnd_xorshft128[1] = (s1 ^ s0 ^ (s1 >> 17) ^ (s0 >> 26))) + s0;
}

static int my_nextbuffer(void)
{
    uint8_t position = (int)((g_array_pos * 4) / 64);
    uint8_t roll = g_array_pos % 16;
    uint8_t _nextbuffer = (g_my_prng_arrays[MY_NUM_OF_RND_ARRAYS][position] >> (roll * 4)) & (MY_NUM_OF_RND_ARRAYS - 1);

    while (mutex_lock_interruptible(&g_mutex_update_pos));
    g_array_pos++;
    mutex_unlock(&g_mutex_update_pos);

    if (g_array_pos >= 1021)
    {
        while (mutex_lock_interruptible(&g_mutex_update_pos));
        g_array_pos = 0;
        mutex_unlock(&g_mutex_update_pos);

        my_update_array(MY_NUM_OF_RND_ARRAYS);
    }

    return _nextbuffer;
}

static int my_background_work_thread(void *data)
{
    int iteration = 0;

    while (!kthread_should_stop())
    {

        if (iteration <= MY_NUM_OF_RND_ARRAYS)
        {
            my_update_array(iteration);
        }
        else if (iteration == MY_NUM_OF_RND_ARRAYS + 1)
        {
            my_seed_PRND_r128_0();
        }
        else if (iteration == MY_NUM_OF_RND_ARRAYS + 2)
        {
            my_seed_PRND_r128_1();
        }
        else if (iteration == MY_NUM_OF_RND_ARRAYS + 3)
        {
            my_seed_PRND_r64();
        }
        else
        {
            iteration = -1;
        }

        iteration++;

        ssleep(MY_THREAD_SLEEP_VALUE);
    }

    return 0;
}

static int my_proc_read(struct seq_file *m, void *v)
{
    seq_printf(m, "-----------------------:----------------------\n");
    seq_printf(m, "Device                 : /dev/" MY_TEST_DEVICE_NAME "\n");

    seq_printf(m, "Module version         : " MY_APP_VERSION "\n");

    seq_printf(m, "Current open count     : %d\n", g_dev_open_current);
    seq_printf(m, "Total open count       : %d\n", g_dev_open_total);
    seq_printf(m, "Total K bytes          : %llu\n", g_generated_count / 2);
    seq_printf(m, "-----------------------:----------------------\n");
    seq_printf(m, "Author                 : CIA-penguins\n");

    return 0;
}

static int my_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, my_proc_read, NULL);
}

module_init(my_module_init);
module_exit(my_module_exit);

unsigned long __stack_chk_guard;
void __stack_chk_guard_setup(void)
{
    MY_KERNEL_TIME_GET_NS(&g_ts);
    __stack_chk_guard = (uint64_t)g_ts.tv_nsec;
}

void __stack_chk_fail(void)
{
    printk(KERN_INFO "[pseudo_quantropi] Stack Guard check Failed!\n");
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR(MY_MODULE_AUTHOR);
MODULE_DESCRIPTION(MY_DRIVER_DESC);
