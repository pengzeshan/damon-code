
check: 
restorecon, chcon
apt-get install policycoreutils