#include <stdio.h>
#include <fcntl.h>
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>

#define my_BUFFER_LENGTH 256
static char my_buffer[my_BUFFER_LENGTH];

char * dev_random_filename = "/dev/random";
char * dev_urandom_filename = "/dev/urandom";
char * dev_srandom_filename = "/dev/srandom";

char * dev_pseudo_random_filename = "/dev/pseudo_random"; // ls -i /dev/pseudo_random --> 482 /dev/pseudo_random
char * dev_pseudo_urandom_filename = "/dev/pseudo_urandom"; // ls -i /dev/pseudo_urandom  --> 484 /dev/pseudo_urandom
char * dev_peudo_quantropi_filename = "/dev/pseudo_quantropi"; // ls -i /dev/pseudo_quantropi  --> 486 /dev/pseudo_quantropi

void print_data(char * buf, int len) {
    unsigned char * tmp = (unsigned char*) buf;
    for(int i = 0; i < len; i++) {
        printf("%02x ", *(tmp+i));
        fflush(stdout);
    }
    printf("\n");
}
int test_pseudo_dev(char * dev_filename) {
    int ret, fd;
    char message[my_BUFFER_LENGTH];
    char * PRFIX_MSG = "...msg from ";
    char * SUFFIX_MSG = "...";

    printf("Opening %s...\n", dev_filename);
    fflush(stdout);
    fd = open(dev_filename, O_RDWR);
    if (fd < 0) {
        perror("Failed: open device...");
        return errno;
    }
    strcpy(message, PRFIX_MSG);
    strcpy(message + strlen(PRFIX_MSG), dev_filename);
    strcpy(message + strlen(PRFIX_MSG) + strlen(dev_filename), SUFFIX_MSG);

    printf("Sending: [%s]\n", message);
    ret = write(fd, message, strlen(message));
    if (ret < 0) {
        perror("Failed: write the message to the device.");
        return errno;
    }

    printf("Sent! Press ENTER to read back from the device...\n");
    getchar();

    printf("Reading the device...\n");
    ret = read(fd, my_buffer, my_BUFFER_LENGTH);
    if (ret < 0){
        perror("Failed: read the message from the device.");
        return errno;
    }
    printf("Received: [%s]\n\n\n", my_buffer);

    return 0;
}




void test_dev(char * dev_filename) {
    printf("Opening %s...\n", dev_filename);
    int randomDataFD = open(dev_filename, O_RDONLY);
    if (randomDataFD < 0)
    {
        printf(" error in opening %s\n", dev_filename);
    }
    else
    {
        char myRandomData[50];
        size_t randomDataLen = 0;
        while (randomDataLen < sizeof myRandomData)
        {
            printf("Reading 50 random bytes: ");
            size_t result = read(randomDataFD, myRandomData + randomDataLen, (sizeof myRandomData) - randomDataLen);
            if (result < 0)
            {
                printf(" error in reading %s with ret=%ld\n", dev_filename, result);
            }
            randomDataLen += result;
        }
        close(randomDataFD);
        print_data(myRandomData, sizeof(myRandomData));
        printf("\n\n\n");
    }
}



int main(int argc, char * argv[]) {
/*
    test_dev(dev_random_filename);
    test_dev(dev_urandom_filename);
    test_dev(dev_srandom_filename);
*/
  if (argc != 2) 
    return -1;
  if (strcmp(argv[1], "1") == 0) {
    test_pseudo_dev(dev_pseudo_random_filename);
  }
  if (strcmp(argv[1], "2") == 0) {
    test_pseudo_dev(dev_pseudo_urandom_filename);
  }
  if (strcmp(argv[1], "3") == 0) {
    test_pseudo_dev(dev_peudo_quantropi_filename);
  }
    return 0;
}
