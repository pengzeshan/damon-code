#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/slab.h>      
#include <linux/gfp.h>
#include <linux/vmalloc.h>   
#include <linux/uaccess.h>   
#include <linux/miscdevice.h>
#include <linux/time.h>      
#include <linux/proc_fs.h>   
#include <linux/seq_file.h>  
#include <linux/mutex.h>
#include <linux/delay.h>
#include <linux/kthread.h>

#define MY_DRIVER_AUTHOR "CIA-penguins Canada"
#define MY_DRIVER_DESC   "pseudo random number generator."
#define MY_SDEVICE_NAME "pseudo_quantropi"
#define MY_APP_VERSION "0.0.1"
#define THREAD_SLEEP_VALUE_11 11

#define RND_ARRAY_SIZE_67       67
#define NUM_OF_RAND_ARRAYS_16   16

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,12,0)
    #define COPY_TO_USER raw_copy_to_user
    #define COPY_FROM_USER raw_copy_from_user
#else
    #define COPY_TO_USER copy_to_user
    #define COPY_FROM_USER copy_from_user
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,8,0)
    #define KTIME_GET_NS ktime_get_real_ts64
    #define TIMESPEC timespec64
#else
    #define KTIME_GET_NS getnstimeofday
    #define TIMESPEC timespec
#endif

/* file opertions for register and deregister*/
static int      my_device_open(struct inode *, struct file *);
static int      my_device_release(struct inode *, struct file *);
static ssize_t  my_pseudo_device_read(struct file *, char *, size_t, loff_t *);
static ssize_t  my_pseudo_device_write(struct file *, const char *, size_t, loff_t *);
static struct file_operations my_file_ops = {
        .owner   = THIS_MODULE,
        .open    = my_device_open,
        .read    = my_pseudo_device_read,
        .write   = my_pseudo_device_write,
        .release = my_device_release
};
static struct miscdevice my_pseudo_quantropi_dev = {
        MISC_DYNAMIC_MINOR,
        "pseudo_quantropi",
        &my_file_ops
};

/* file operations for proc */
static int my_proc_read(struct seq_file *m, void *v);
static int my_proc_open(struct inode *inode, struct  file *file);
static int my_work_thread(void *data);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,8,0)
static struct proc_ops my_proc_file_ops={
      .proc_open = my_proc_open,
      .proc_release = single_release,
      .proc_read = seq_read,
      .proc_lseek = seq_lseek
};
#else
static const struct file_operations my_proc_file_ops = {
        .owner   = THIS_MODULE,
        .read    = seq_read,
        .open    = my_proc_open,
        .llseek  = seq_lseek,
        .release = single_release,
};
#endif

static struct mutex mutex_update_array;
uint64_t (*prng_arrays)[NUM_OF_RAND_ARRAYS_16 + 1];
uint64_t pseudio_generated_count;

static struct mutex mutex_dev_open_release;
int16_t  pseudio_dev_open_current_idx;
int32_t  pseudio_dev_open_total;

static struct mutex mutex_arrays_busy_mask;
uint16_t my_arrays_busy_mask = 0;

static struct mutex mutex_arrays_buffer_pos;
int      my_arrays_buffer_pos = 0;

/* seeds related global varaibles and functions */
uint64_t seed_1_for_64;
uint64_t seed_2_for_128[2];
struct   TIMESPEC my_timestamp;
static void seed_PRND_1_for_64(void) {
         KTIME_GET_NS(&my_timestamp);
         seed_2_for_128[0] = (seed_2_for_128[0] << 31) ^ (uint64_t)my_timestamp.tv_nsec;
}
static void seed_PRND_2_for_64(void) {
        KTIME_GET_NS(&my_timestamp);
        seed_2_for_128[1] = (seed_2_for_128[1] << 24) ^ (uint64_t)my_timestamp.tv_nsec;
}
static void seed_PRND_for_128(void) {
        KTIME_GET_NS(&my_timestamp);
        seed_1_for_64 = (seed_1_for_64 << 32) ^ (uint64_t)my_timestamp.tv_nsec;
}
static uint64_t xorshft64(void) {
        uint64_t z = (seed_1_for_64 += 0x9E3779B97F4A7C15ULL);
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
        return z ^ (z >> 31);
}
static uint64_t xorshft128(void) {
        uint64_t        s1 = seed_2_for_128[0];
        const uint64_t  s0 = seed_2_for_128[1];
        seed_2_for_128[0] = s0;
        s1 ^= s1 << 23;
        return (seed_2_for_128[ 1 ] = (s1 ^ s0 ^ (s1 >> 17) ^ (s0 >> 26))) + s0;
}

static int  my_nextbuffer_func(void);
static void my_update_array(int);

static struct task_struct *kthread;

/*
 * This function is called when the module is loaded
 */
int my_mod_init(void)
{
        int16_t _idx;
        int16_t array_idx;

        pseudio_dev_open_current_idx = 0;
        pseudio_dev_open_total   = 0;
        pseudio_generated_count  = 0;

        mutex_init(&mutex_update_array);
        mutex_init(&mutex_dev_open_release);
        mutex_init(&mutex_arrays_busy_mask);
        mutex_init(&mutex_arrays_buffer_pos);

        KTIME_GET_NS(&my_timestamp);
        seed_1_for_64 = (uint64_t)my_timestamp.tv_nsec;
        seed_2_for_128[0] = xorshft64();
        seed_2_for_128[1] = xorshft64();

        /*
         * Register char device
         */
        if (misc_register(&my_pseudo_quantropi_dev))
                printk(KERN_INFO "[pseudo_quantropi] my_mod_init /dev/pseudo_quantropi driver registion failed..\n");
        else
                printk(KERN_INFO "[pseudo_quantropi] my_mod_init /dev/pseudo_quantropi driver registered..\n");

        /*
         * Create /proc/pseudo_quantropi
         */
        if (! proc_create("pseudo_quantropi", 0, NULL, &my_proc_file_ops))
                printk(KERN_INFO "[pseudo_quantropi] my_mod_init /proc/pseudo_quantropi registion failed..\n");
        else
                printk(KERN_INFO "[pseudo_quantropi] my_mod_init /proc/pseudo_quantropi registion regisered..\n");

        printk(KERN_INFO "[pseudo_quantropi] my_mod_init Module version         : "MY_APP_VERSION"\n");
        printk(KERN_INFO "-----------------------:----------------------\n");
        printk(KERN_INFO "Author                 : CIA-penguins Canada\n");


        prng_arrays = kmalloc((NUM_OF_RAND_ARRAYS_16 + 1) * RND_ARRAY_SIZE_67 * sizeof(uint64_t), GFP_KERNEL);
        while (!prng_arrays) {
                printk(KERN_INFO "[pseudo_quantropi] my_mod_init kmalloc failed to allocate initial memory.  retrying...\n");
                prng_arrays = kmalloc((NUM_OF_RAND_ARRAYS_16 + 1) * RND_ARRAY_SIZE_67 * sizeof(uint64_t), GFP_KERNEL);
        }

        seed_PRND_1_for_64();
        seed_PRND_2_for_64();
        seed_PRND_for_128();

        for (array_idx = 0; array_idx <= NUM_OF_RAND_ARRAYS_16 ; array_idx++) {
                for (_idx = 0; _idx <= RND_ARRAY_SIZE_67; _idx++) {
                        prng_arrays[array_idx][_idx] = xorshft128();
                }
                my_update_array(array_idx);
        }

        kthread = kthread_create(my_work_thread, NULL, "pseudo_quantropi-kthread");
        wake_up_process(kthread);

        return 0;
}

/*
 * This function is called when the module is unloaded
 */
void my_mod_exit(void)
{
        kthread_stop(kthread);
        misc_deregister(&my_pseudo_quantropi_dev);
        remove_proc_entry("pseudo_quantropi", NULL);
        printk(KERN_INFO "[pseudo_quantropi] my_mod_exit pseudo_quantropi deregisered..\n");
}


/*
 * This function is called when a process tries to open the device file. "dd if=/dev/pseudo_quantropi"
 */
static int my_device_open(struct inode *inode, struct file *file)
{
        while (mutex_lock_interruptible(&mutex_dev_open_release));

        pseudio_dev_open_current_idx++;
        pseudio_dev_open_total++;

        mutex_unlock(&mutex_dev_open_release);
        return 0;
}


static int my_device_release(struct inode *inode, struct file *file)
{
        while (mutex_lock_interruptible(&mutex_dev_open_release));

        pseudio_dev_open_current_idx--;
        mutex_unlock(&mutex_dev_open_release);
        return 0;
}

static ssize_t my_pseudo_device_read(struct file * file, char * buf, size_t requestedCount, loff_t *ppos)
{
        int array_idx;
        int block_idx, ret;
        char *new_buf;
        bool use_vmalloc = 0;
        int i = 0;

        new_buf = kmalloc((requestedCount + 512) * sizeof(uint8_t), GFP_KERNEL|__GFP_NOWARN);
        while (!new_buf) {
                use_vmalloc = 1;
                new_buf = vmalloc((requestedCount + 512) * sizeof(uint8_t));
        }

        while (mutex_lock_interruptible(&mutex_arrays_busy_mask));

        array_idx = my_nextbuffer_func();

        while ((my_arrays_busy_mask & 1 << array_idx) == (1 << array_idx)) {
                array_idx += 1;
                if (array_idx >= NUM_OF_RAND_ARRAYS_16) {
                        array_idx = 0;
                }
        }

        my_arrays_busy_mask += (1 << array_idx);
        mutex_unlock(&mutex_arrays_busy_mask);

        for (block_idx = 0; block_idx <= (requestedCount / 512); block_idx++) {
                memcpy(new_buf + (block_idx * 512), prng_arrays[array_idx], 512);
                my_update_array(array_idx);
        }

        {
                /* the first 5 bytes are 1 for pseudo_quantropi: just for fun*/
                for(i = 0; i< 5; i++)
                        new_buf[i] = 1;
        }

        ret = COPY_TO_USER(buf, new_buf, requestedCount);
        if (use_vmalloc) {
                vfree(new_buf);
        } else {
                kfree(new_buf);
        }

        if (mutex_lock_interruptible(&mutex_arrays_busy_mask))
                return -ERESTARTSYS;
        my_arrays_busy_mask -= (1 << array_idx);
        mutex_unlock(&mutex_arrays_busy_mask);

        return requestedCount;
}

/*
 * Called when someone tries to write to /dev/pseudo_quantropi device
 */
static ssize_t my_pseudo_device_write(struct file *file, const char __user *buf, size_t received_size, loff_t *ppos)
{
        char *newdata;
        int result;

        newdata = kmalloc(received_size, GFP_KERNEL);
        while (!newdata) {
                newdata = kmalloc(received_size, GFP_KERNEL);
        }
        result = COPY_FROM_USER(newdata, buf, received_size);

        kfree(newdata);
        return received_size;
}

/*
 * Update the prng_arrays with new random numbers
 */
void my_update_array(int array_idx)
{
        int16_t _idx;
        int64_t X, Y, Z1, Z2, Z3;

        while (mutex_lock_interruptible(&mutex_update_array));
        pseudio_generated_count++;
        Z1 = xorshft64();
        Z2 = xorshft64();
        Z3 = xorshft64();
        if ((Z1 & 1) == 0) {
                for (_idx = 0; _idx < (RND_ARRAY_SIZE_67 -4); _idx = _idx + 4) {
                        X=xorshft128();
                        Y=xorshft128();
                        prng_arrays[array_idx][_idx + 0] = prng_arrays[array_idx][_idx + 1] ^ X ^ Y;
                        prng_arrays[array_idx][_idx + 1] = prng_arrays[array_idx][_idx + 2] ^ Y ^ Z1;
                        prng_arrays[array_idx][_idx + 2] = prng_arrays[array_idx][_idx + 3] ^ X ^ Z2;
                        prng_arrays[array_idx][_idx + 3] = X ^ Y ^ Z3;
                }
        } else {
                for (_idx = 0;_idx < (RND_ARRAY_SIZE_67 -4) ;_idx = _idx + 4) {
                        X=xorshft128();
                        Y=xorshft128();
                        prng_arrays[array_idx][_idx + 0] = prng_arrays[array_idx][_idx + 1] ^ X ^ Z2;
                        prng_arrays[array_idx][_idx + 1] = prng_arrays[array_idx][_idx + 2] ^ X ^ Y;
                        prng_arrays[array_idx][_idx + 2] = prng_arrays[array_idx][_idx + 3] ^ Y ^ Z3;
                        prng_arrays[array_idx][_idx + 3] = X ^ Y ^ Z1;
                }
        }
        mutex_unlock(&mutex_update_array);
}

/*
 *  This function returns the next prng_arrays to use/read.
 */
int my_nextbuffer_func(void)
{
        uint8_t position = (int)((my_arrays_buffer_pos * 4) / 64 );
        uint8_t roll = my_arrays_buffer_pos % 16;
        uint8_t next_buffer = (prng_arrays[NUM_OF_RAND_ARRAYS_16][position] >> (roll * 4)) & (NUM_OF_RAND_ARRAYS_16 -1);

        while (mutex_lock_interruptible(&mutex_arrays_buffer_pos));
        my_arrays_buffer_pos ++;
        mutex_unlock(&mutex_arrays_buffer_pos);

        if (my_arrays_buffer_pos >= 1021) {
                while (mutex_lock_interruptible(&mutex_arrays_buffer_pos));
                my_arrays_buffer_pos = 0;
                mutex_unlock(&mutex_arrays_buffer_pos);

                my_update_array(NUM_OF_RAND_ARRAYS_16);
        }

        return next_buffer;
}

/*
 *  The Kernel thread doing background tasks.
 */
int my_work_thread(void *data)
{
        int iteration = 0;

        while (!kthread_should_stop()) {

                if (iteration <= NUM_OF_RAND_ARRAYS_16) {
                  my_update_array(iteration);
                }
                else if (iteration == NUM_OF_RAND_ARRAYS_16 + 1) {
                  seed_PRND_1_for_64();
                }
                else if (iteration == NUM_OF_RAND_ARRAYS_16 + 2) {
                  seed_PRND_2_for_64();
                }
                else if (iteration == NUM_OF_RAND_ARRAYS_16 + 3) {
                  seed_PRND_for_128();
                }
                else {
                  iteration = -1;
                }

                iteration++;

                ssleep(THREAD_SLEEP_VALUE_11);
        }

        return 0;
 }

/*
 * This function is called when reading /proc filesystem
 */
int my_proc_read(struct seq_file *m, void *v)
{
        seq_printf(m, "-----------------------:----------------------\n");
        seq_printf(m, "Device                 : /dev/"MY_SDEVICE_NAME"\n");
        seq_printf(m, "Module version         : "MY_APP_VERSION"\n");
        seq_printf(m, "Current open count     : %d\n",pseudio_dev_open_current_idx);
        seq_printf(m, "Total open count       : %d\n",pseudio_dev_open_total);
        seq_printf(m, "Total K bytes          : %llu\n",pseudio_generated_count / 2);
        seq_printf(m, "-----------------------:----------------------\n");
        seq_printf(m, "Author                 :CIA-penguins Canada\n");
        return 0;
}

int my_proc_open(struct inode *inode, struct  file *file)
{
        return single_open(file, my_proc_read, NULL);
}

module_init(my_mod_init);
module_exit(my_mod_exit);

unsigned long __stack_chk_guard;
void __stack_chk_guard_setup(void)
{
        KTIME_GET_NS(&my_timestamp);
        __stack_chk_guard = (uint64_t)my_timestamp.tv_nsec;
}

void __stack_chk_fail(void)
{
        printk(KERN_INFO "[pseudo_quantropi] Stack Guard check Failed!\n");
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR(MY_DRIVER_AUTHOR);
MODULE_DESCRIPTION(MY_DRIVER_DESC);
