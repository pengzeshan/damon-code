
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>

#define my_BUFFER_LENGTH 256
#define my_DEVICE_NAME "/dev/pseudo_urandom"
static char my_buffer[my_BUFFER_LENGTH];

int main() {
    int ret, fd;
    char message[my_BUFFER_LENGTH];

    printf("Opening %s...", my_DEVICE_NAME);
    fd = open(my_DEVICE_NAME, O_RDWR);
    if (fd < 0) {
        perror("Failed: open device...");
        return errno;
    }

    printf("Opened! Enter a message:");
    scanf("%[^\n]%*c", message);

    printf("Sending: [%s]\n", message);
    ret = write(fd, message, strlen(message));
    if (ret < 0) {
        perror("Failed: write the message to the device.");
        return errno;
    }

    printf("Sent! Press ENTER to read back from the device...\n");
    getchar();

    printf("Reading the device...\n");
    ret = read(fd, my_buffer, my_BUFFER_LENGTH);
    if (ret < 0){
        perror("Failed: read the message from the device.");
        return errno;
    }
    printf("Received: [%s]\n", my_buffer);

    return 0;
}
