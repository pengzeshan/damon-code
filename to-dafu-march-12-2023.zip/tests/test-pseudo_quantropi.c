#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

static char * dev_pseudo_quantropi_filename = "/dev/pseudo_quantropi";
static void print_data(char * buf, int len) {
    unsigned char * tmp = (unsigned char*) buf;
    for(int i = 0; i < len; i++) {
        printf("%02x ", *(tmp+i));
        fflush(stdout);
    }
    printf("\n");
}

void test_pseudo_quantropi(void) {
    printf("open %s\n", dev_pseudo_quantropi_filename);
    int fd_random_data = open(dev_pseudo_quantropi_filename, O_RDONLY);
    if (fd_random_data < 0)
    {
        printf(" error in open %s\n", dev_pseudo_quantropi_filename);
    }
    else
    {
        char my_random_data[50];
        printf("read %ld bytes from %s:\n", sizeof my_random_data, dev_pseudo_quantropi_filename);
        size_t result = read(fd_random_data, my_random_data, sizeof my_random_data);
        if (result < 0)
        {
            printf(" error in read %s withe ret=%ld\n", dev_pseudo_quantropi_filename, result);     
       }
        close(fd_random_data);        
        print_data(my_random_data, sizeof(my_random_data));
        printf("\n\n\n");  
    }
}

int main(void) {
    test_pseudo_quantropi();
    return 0;
}