#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

// static char * dev_urandom_filename = "/dev/pseudo_urandom";
static char * dev_urandom_filename = "/dev/urandom";
static void print_data(char * buf, int len) {
    unsigned char * tmp = (unsigned char*) buf;
    for(int i = 0; i < len; i++) {
        printf("%02x ", *(tmp+i));
        fflush(stdout);
    }
    printf("\n");
}

void test_urandom(void) {
    printf("open %s\n", dev_urandom_filename);
    int fd_random_data = open(dev_urandom_filename, O_RDONLY);
    if (fd_random_data < 0)
    {
        printf(" error in open %s\n", dev_urandom_filename);
    }
    else
    {
        char my_urandom_data[50];
        printf("read %ld bytes from %s:\n", sizeof my_urandom_data, dev_urandom_filename);
        size_t result = read(fd_random_data, my_urandom_data, sizeof my_urandom_data);
        if (result < 0)
        {
            printf(" error in read %s withe ret=%ld\n", dev_urandom_filename, result);
        }
        close(fd_random_data);        
        print_data(my_urandom_data, sizeof(my_urandom_data));
        printf("\n\n\n");        
    }
}

int main(void) {
    test_urandom();
    return 0;
}